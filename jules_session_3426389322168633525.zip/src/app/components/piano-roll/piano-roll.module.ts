import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PianoRollComponent } from './piano-roll.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  exports: []
})
export class PianoRollModule { }
